"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { FAVORITES_EVENT, mergeLocalFavoritesIntoAccount } from "@/lib/favorites";

export default function AuthForm({ onSuccess }: { onSuccess?: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMessage(null);

    if (mode === "signup") {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) {
        setMessage(error.message);
      } else if (data.user && !data.session) {
        setMessage("Check your email to confirm your account, then sign in.");
      } else if (data.user) {
        await mergeLocalFavoritesIntoAccount(data.user.id);
        window.dispatchEvent(new Event(FAVORITES_EVENT));
        onSuccess?.();
      }
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        setMessage(error.message);
      } else if (data.user) {
        await mergeLocalFavoritesIntoAccount(data.user.id);
        window.dispatchEvent(new Event(FAVORITES_EVENT));
        onSuccess?.();
      }
    }
    setBusy(false);
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="auth-form">
        <div className="auth-input-wrap">
          <svg className="auth-input-icon" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 4h16v16H4z" opacity="0" />
            <path d="M22 6l-10 7L2 6" />
            <rect x="2" y="4" width="20" height="16" rx="3" />
          </svg>
          <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="auth-input-wrap">
          <svg className="auth-input-icon" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="11" width="18" height="10" rx="2" />
            <path d="M7 11V7a5 5 0 0 1 10 0v4" />
          </svg>
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
          />
        </div>
        <button type="submit" className="profile-btn-primary" disabled={busy} style={{ width: "100%", marginTop: 4 }}>
          {busy ? "Please wait..." : mode === "signin" ? "Sign In" : "Create Account"}
        </button>
      </form>
      {message && <p className="auth-message">{message}</p>}
      <button
        type="button"
        onClick={() => {
          setMode(mode === "signin" ? "signup" : "signin");
          setMessage(null);
        }}
        className="auth-toggle"
      >
        {mode === "signin" ? "New here? Create an account" : "Already have an account? Sign in"}
      </button>
    </>
  );
}
